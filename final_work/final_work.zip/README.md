# README

大作业提交文件目录介绍

- 压缩包中`image`是存放大作业中的图片
- `bibliography.bib`存放引用文献的bibtex
- `final.tex`为tex代码
- `final_game.pdf`为最终导出的pdf

> 1120212477 董林康